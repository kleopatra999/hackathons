setTimeout(function(){
console.log('hello')
},2000)
console.log('world')
